/*
 * File: sort.cpp
 * --------------
 * This file implements the sort.h interface.
 */

#include "sort.h"
#include "console.h"
using namespace std;

/* Prototypes */

void swap(int & v1, int & v2);

/*
 * Implementation notes: sort
 * --------------------------
 * This implementation uses an algorithm called selection sort, which can
 * be described as follows.  With your left hand (lh), point at each element
 * in the array in turn, starting at index 0.  At each step in the cycle:
 *
 * 1. Find the smallest element in the range between your left hand and the
 *    end of the array, and point at that element with your right hand (rh).
 *
 * 2. Move that element into its correct position by exchanging the elements
 *    indicated by your left and right hands.
 */

void sort(int array[], int n) {
   for (int lh = 0; lh < n; lh++) {
      int rh = lh;
      for (int i = lh + 1; i < n; i++) {
         if (array[i] < array[rh]) rh = i;
      }
      swap(array[lh], array[rh]);
   }
}

void swap(int & v1, int & v2) {
   int tmp = v1;
   v1 = v2;
   v2 = tmp;
}
