/*
 * File: TestSelectionSort.cpp
 * ---------------------------
 * This file implements a very simple test of the template-based
 * selection sort algorithm that shows it works with two kinds of
 * arrays.
 */

#include <iostream>
#include <string>
#include "console.h"
#include "sort.h"
using namespace std;

/* Function prototypes */

void printArray(int array[], int n);

/* Main program */

int main() {
   int intArray[] = { 31, 41, 59, 26, 53, 58, 97, 93 };
   sort(intArray, 8);
   cout << "intArray: ";
   printArray(intArray, 8);
   return 0;
}

void printArray(int array[], int n) {
   cout << "{";
   for (int i = 0; i < n; i++) {
      if (i > 0) cout << ", ";
      cout << array[i];
   }
   cout << "}" << endl;
}
