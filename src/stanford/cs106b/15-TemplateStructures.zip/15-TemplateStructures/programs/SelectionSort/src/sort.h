/*
 * File: sort.h
 * ------------
 * This interface exports a function that sorts an array of ints.
 */

#ifndef _sort_h
#define _sort_h

/*
 * Function: sort
 * Usage: sort(array);
 * -------------------
 * This function sorts the elements of the array into increasing order.
 */

void sort(int array[], int n);

#endif
