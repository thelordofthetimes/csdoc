README.txt file for FindAnagrams
