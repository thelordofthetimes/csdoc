/*
 * File: queuetest.cpp
 * -------------------
 * This program tests the Queue package by creating a test
 * program that implements the following commands:
 *
 *     enqueue str -- Adds the string onto the queue
 *     dequeue     -- Dequeues and prints the first value
 *     peek        -- Peeks at the first element
 *     size        -- Prints the size of the queue
 *     isEmpty     -- Prints whether the queue is empty
 *     clear       -- Clears the queue
 *     list        -- List the elements of the queue
 *     quit        -- Quits the program
 */

#include "genlib.h"
#include "console.h"
#include "simpio.h"
#include "scanner.h"
#include "queue.h"
#include <iostream>

/* Function prototypes */

void ExecuteCommand(Queue<string> & queue, Scanner & scanner);
void ListQueue(Queue<string> & queue);

/* Main program */

int main() {
	SetConsoleSize(18);
	Queue<string> queue;
	Scanner scanner;
	scanner.setSpaceOption(Scanner::IgnoreSpaces);
	scanner.setStringOption(Scanner::ScanQuotesAsStrings);
	while (true) {
		cout << "> ";
		string line = GetLine();
		scanner.setInput(line);
		if (scanner.hasMoreTokens()) {
			ExecuteCommand(queue, scanner);
		}
	}
	return 0;
}

void ExecuteCommand(Queue<string> & queue, Scanner & scanner) {
	string cmd = scanner.nextToken();
	string arg = "";
	if (cmd == "enqueue") {
		arg = scanner.nextToken();
		if (arg[0] == '"') {
			arg = arg.substr(1, arg.length() - 2);
		}
	}
	if (scanner.hasMoreTokens()) {
		cout << "Unexpected token: " << scanner.nextToken() << endl;
	} else if (cmd == "quit") {
		exit(0);
	} else if (cmd == "enqueue") {
		queue.enqueue(arg);
	} else if (cmd == "dequeue") {
		if (queue.isEmpty()) {
			cout << "Queue is empty" << endl;
		} else {
			cout << queue.dequeue() << endl;
		}
	} else if (cmd == "peek") {
		if (queue.isEmpty()) {
			cout << "Queue is empty" << endl;
		} else {
			cout << queue.peek() << endl;
		}
	} else if (cmd == "size") {
		cout << queue.size() << endl;
	} else if (cmd == "isEmpty") {
		cout << ((queue.isEmpty()) ? "true" : "false") << endl;
	} else if (cmd == "clear") {
		queue.clear();
	} else if (cmd == "list") {
		if (queue.isEmpty()) {
			cout << "Queue is empty" << endl;
		} else {
			ListQueue(queue);
			cout << endl;
		}
	} else {
		cout << "Unrecognized command: " << cmd << endl;
	}
}

void ListQueue(Queue<string> & queue) {
	int count = queue.size();
	for (int i = 0; i < count; i++) {
		string str = queue.dequeue();
		if (i > 0) cout << " ";
		cout << str;
		queue.enqueue(str);
	}
}

		
