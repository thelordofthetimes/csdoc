/*
 * File: queue.h
 * -------------
 * This interface defines a general queue abstraction that uses
 * templates so that it can work with any element type.
 */

#ifndef _queue_h
#define _queue_h

/*
 * Template class: Queue<ElemType>
 * -------------------------------
 * This class template models a queue, which is a linear collection
 * of values that resemble a waiting line.  Values are added at
 * one end of the queue and removed from the other.  The fundamental
 * operations are enqueue (add to the tail of the queue) and dequeue
 * (remove from the head of the queue).  Because a queue preserves
 * the order of the elements, the first value enqueued is the first
 * value dequeued.  Queues therefore operate in a first-in-first-out
 * (FIFO) order.  For maximum generality, the Queue class is defined
 * using a template that allows the client to define a queue that
 * contains any type of value, as in Queue<string> or Queue<taskT>.
 */

template <typename ElemType>
class Queue {

  public:

/*
 * Constructor: Queue
 * Usage: Queue<int> queue;
 * ------------------------
 * The constructor initializes a new empty queue containing
 * the specified value type. 
 */

	Queue();


/*
 * Destructor: ~Queue
 * Usage: (usually implicit)
 * -------------------------
 * The destructor deallocates any heap storage associated
 * with this queue.
 */

	~Queue();

/*
 * Member function: size
 * Usage: nElems = queue.size();
 * -----------------------------
 * Returns the number of elements in this queue.
 */

	int size();


/*
 * Method: isEmpty
 * Usage: if (queue.isEmpty()) . . .
 * ---------------------------------
 * Returns true if this queue contains no elements, and false otherwise.
 */

	bool isEmpty();

/*
 * Method: clear
 * Usage: queue.clear();
 * ---------------------
 * This method removes all elements from this queue.
 */

	void clear();

/*
 * Method: enqueue
 * Usage: queue.enqueue(elem);
 * ---------------------------
 * Adds the specified element to the end of this queue.
 */

	void enqueue(ElemType elem);

/*
 * Method: dequeue
 * Usage: first = queue.dequeue();
 * -------------------------------
 * Removes the first element from this queue and returns it.
 * Raises an error if called on an empty queue.
 */

	ElemType dequeue();

/*
 * Method: peek
 * Usage: topElem = queue.peek();
 * ------------------------------
 * Returns the value of first element from this queue without
 * removing it.  Raises an error if called on an empty queue.
 */

	ElemType peek();

/*
 * Deep copying support
 * --------------------
 * To maintain the desired behavior for a queue, copying one
 * queue to another must copy the data in the original queue.
 * This type of copy is called a "deep copy".  Unfortunately,
 * the default behavior of C++ makes only a "shallow copy" in
 * which any pointer variables in the private data are simply
 * copied as addresses.  To ensure that the Queue class performs
 * the necessary deep copy, it is necessary to override the
 * behavior of two methods:
 *
 * 1. The assignment operator (written as operator= in C++)
 * 2. The copy constructor that initializes one Queue from another
 * 
 * Even though these operations must be supported to guarantee
 * correct behavior, you should avoid making copies of queues
 * wherever possible.  To do so, the usual strategy is to pass
 * queues by reference so that the queue is shared rather than
 * copied.
 *
 * Note: The keyword const in each of these operators is required
 * as part of the definition of these methods.  The interpretation
 * of const is sufficiently complex that we use it only in a few
 * standard idiomatic patterns (such as this one) where the language
 * requires it.
 */

	const Queue & operator=(const Queue & rhs);
	Queue(const Queue & rhs);

  private:

#include "queuepriv.h"

};

/*
 * The template feature of C++ works correctly only if the compiler
 * has access to both the interface and the implementation at the
 * same time.  As a result, the compiler must see the code for
 * the implementation at this point, even though that code is
 * not something that the client needs to see in the interface.
 * Using the #include facility of the C++ preprocessor allows the
 * compiler to have access to the code without forcing the client
 * to wade through the details.
 */

#include "queueimpl.cpp"

#endif

