/*
 * File: queuepriv.h
 * -----------------
 * This file contains the private section of the Queue template
 * class.  Including this information in a separate file means
 * that clients don't need to look at these details.
 */

/* Instance variables */

	ElemType *elements;   /* A dynamic array of the elements     */
	int head;             /* The index of the head of the queue  */
	int tail;             /* The index of the tail of the queue  */
	int capacity;         /* The allocated size of the array     */

/* Private method prototypes */

	void expandCapacity();
    void copyInternalData(const Queue & oldQueue);
