/*
 * File: queueimpl.cpp
 * -------------------
 * This file contains the list-based implementation of the
 * Queue class.
 */

#ifdef _queue_h

/*
 * Implementation notes: Queue data structure
 * ------------------------------------------
 * The list-based queue uses a linked list to store the elements
 * of the queue.  To ensure that adding a new element to the tail
 * of the queue is fast, the data structure maintains a pointer
 * to the last cell in the queue as well as the first.  If the
 * queue is empty, the tail pointer is always set to be NULL.
 */

/*
 * Implementation notes: Queue constructor
 * ---------------------------------------
 * The constructor must create an empty linked list and then
 * initialize the fields of the object.
 */

template <typename ElemType>
Queue<ElemType>::Queue() {
	head = tail = NULL;
    count = 0;
}

/*
 * Implementation notes: ~Queue destructor
 * ---------------------------------------
 * The destructor frees any memory that is allocated by the
 * implementation.  Freeing this memory guarantees the client
 * that the queue abstraction will not "leak memory" in the
 * process of running an application.  Because clear frees
 * each element it processes, this implementation of the
 * destructor simply calls that method.
 */

template <typename ElemType>
Queue<ElemType>::~Queue() {
	clear();
}

/*
 * Implementation notes: size, isEmpty, clear
 * ------------------------------------------
 * These implementations should be self-explanatory.
 */

template <typename ElemType>
int Queue<ElemType>::size() {
	return count;
}

template <typename ElemType>
bool Queue<ElemType>::isEmpty() {
	return count == 0;
}

template <typename ElemType>
void Queue<ElemType>::clear() {
	while (count > 0) {
		dequeue();
	}
}

/*
 * Implementation notes: enqueue
 * -----------------------------
 * This method allocates a new list cell and chains it in
 * at the tail of the queue.  If the queue is currently empty,
 * the new cell must also become the head pointer in the queue.
 */

template <typename ElemType>
void Queue<ElemType>::enqueue(ElemType elem) {
	cellT *cell = new cellT;
	cell->data = elem;
	cell->link = NULL;
	if (head == NULL) {
		head = cell;
	} else {
		tail->link = cell;
	}
	tail = cell;
	count++;
}

/*
 * Implementation notes: dequeue, peek
 * -----------------------------------
 * These methods must check for an empty queue and report an
 * error if there is no first element.  The dequeue method
 * must also check for the case in which the queue becomes
 * empty and set both the head and tail pointers to NULL.
 */

template <typename ElemType>
ElemType Queue<ElemType>::dequeue() {
	if (isEmpty()) Error("dequeue: Attempting to dequeue an empty queue");
	cellT *cell = head;
	ElemType result = cell->data;
	head = cell->link;
	if (head == NULL) tail = NULL;
	count--;
	delete cell;
	return result;
}

template <typename ElemType>
ElemType Queue<ElemType>::peek() {
	if (isEmpty()) Error("peek: Attempting to peek at an empty queue");
	return head->data;
}

/*
 * Implementation notes: deep copying support
 * ------------------------------------------
 * The operator= method and the copy constructor must make a copy
 * of the elements array.
 */

template <typename ElemType>
const Queue<ElemType> & Queue<ElemType>::operator=(const Queue & rhs) {
	if (this != &rhs) copyInternalData(rhs);
	return *this;
}

template <typename ElemType>
Queue<ElemType>::Queue(const Queue & rhs) {
	copyInternalData(rhs);
}

/*
 * Implementation notes: copyInternalData
 * --------------------------------------
 * This private method copies all of the internal data from
 * the old queue to the current queue object by repeatedly
 * calling enqueue on every element in the old queue.
 */

template <typename ElemType>
void Queue<ElemType>::copyInternalData(const Queue & oldQueue) {
	head = tail = NULL;
	count = 0;
	for (cellT *cp = oldQueue.head; cp != NULL; cp = cp->link) {
		enqueue(cp->data);
	}
}

#endif

