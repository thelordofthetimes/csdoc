/*
 * File: queuepriv.h
 * -----------------
 * This file contains the private section for the list-based
 * implementation of the Queue class.  Including this section
 * in a separate file means that clients don't need to look
 * at these details.
 */

/* Type for linked list cell */

struct cellT {
	ElemType data;
	cellT *link;
};

/* Instance variables */

	cellT *head;       /* Pointer to the cell at the head */
	cellT *tail;       /* Pointer to the cell at the tail */
	int count;         /* Number of elements in the queue */

/* Private method prototypes */

    void copyInternalData(const Queue & oldQueue);
