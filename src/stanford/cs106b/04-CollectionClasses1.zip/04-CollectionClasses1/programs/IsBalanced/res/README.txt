README.txt file for IsBalanced
