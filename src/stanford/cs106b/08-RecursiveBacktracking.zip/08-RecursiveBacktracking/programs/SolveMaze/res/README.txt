README.txt file for SolveMaze
