/*
 * File: RecursiveFactorial.cpp
 * ----------------------------
 * This file generates a table of factorials starting from 0
 * and extending up to some user-specified limit.
 */

#include <iostream>
#include "console.h"
#include "simpio.h"
using namespace std;

/* Function prototypes */

int fact(int n);

/* Main program */

int main() {
   int limit = getInteger("Enter upper limit: ");
   for (int i = 0; i <= limit; i++) {
      cout << i << "! = " << fact(i) << endl;
   }
   return 0;
}

/*
 * Function: fact
 * Usage: int f = fact(n);
 * -----------------------
 * Computes the factorial of n using recursion.
 */

int fact(int n) {
   if (n == 0) {
      return 1;
   } else {
      return n * fact(n - 1);
   }
}
