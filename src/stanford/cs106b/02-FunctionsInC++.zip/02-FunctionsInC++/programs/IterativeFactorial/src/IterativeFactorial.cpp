/*
 * File: IterativeFactorial.cpp
 * ----------------------------
 * This file generates a table of factorials starting from 0
 * and extending up to some user-specified limit.
 */

#include <iostream>
#include "console.h"
using namespace std;

/* Function prototypes */

int fact(int n);

/* Main program */

int main() {
   int limit;
   cout << "Enter upper limit: ";
   cin >> limit;
   for (int i = 0; i <= limit; i++) {
      cout << i << "! = " << fact(i) << endl;
   }
   return 0;
}

/*
 * Function: fact
 * Usage: int f = fact(n);
 * -----------------------
 * Computes the factorial of n using a traditional iterative approach.
 */

int fact(int n) {
   int result = 1;
   for (int i = 1; i <= n; i++) {
      result *= i;
   }
   return result;
}
