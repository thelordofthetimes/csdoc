README.txt file for AirportCodes
