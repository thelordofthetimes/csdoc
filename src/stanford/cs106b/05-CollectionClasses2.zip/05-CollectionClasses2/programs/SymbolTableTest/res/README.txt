README.txt file for SymbolTableTest
