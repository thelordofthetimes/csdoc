README.txt file for FindSHooks
